package com.jarvis.assistant.command

/** Genuine outcome of an action; never SUCCESS unless the result was actually checked or the OS accepted the request. */
enum class ActionStatus {
    ACTION_STARTED, ACTION_SUCCESS, ACTION_FAILED, NEEDS_CONFIRMATION, NEEDS_PERMISSION,
    TARGET_NOT_FOUND, AMBIGUOUS_CONTACT, UNSUPPORTED_ACTION
}

data class CommandResult(
    val success: Boolean,
    val message: String,
    val requiresConfirmation: Boolean = false,
    val followUp: String? = null,
    val source: String = "LOCAL",
    val stopSession: Boolean = false,
    val status: ActionStatus = if (success) ActionStatus.ACTION_SUCCESS else ActionStatus.ACTION_FAILED
)

class ConfirmationManager {
    @Volatile private var pending: (suspend () -> CommandResult)? = null
    val hasPending: Boolean get() = pending != null
    fun set(action: suspend () -> CommandResult) { pending = action }
    fun take(): (suspend () -> CommandResult)? { val p = pending; pending = null; return p }
    fun clear(): Boolean { val had = pending != null; pending = null; return had }
}

/** What the assistant is waiting for in the user's NEXT utterance (besides yes/no confirmations). */
sealed class Awaiting {
    /** Dictation: the next utterance is typed into the focused text field. */
    object TypeText : Awaiting()
    /** Text of a WhatsApp message for [contact] (null = chat selected earlier). */
    data class MessageText(val contact: String?) : Awaiting()
    /** Several WhatsApp contacts matched; the user must pick one. [message] is set if a send is in progress. */
    data class ContactChoice(val candidates: List<String>, val message: String?) : Awaiting()
    /** "search karo" with no text: the next utterance is the web search query. */
    object SearchQuery : Awaiting()
}

/** Short-lived memory of the last WhatsApp chat FRIDAY actually opened, so "usko message bhejo" can refer to it. */
object AssistantContext {
    private const val TTL_MS = 10 * 60 * 1000L
    @Volatile private var lastContact: String? = null
    @Volatile private var lastAt = 0L

    fun setContact(name: String) { lastContact = name; lastAt = System.currentTimeMillis() }
    fun contact(): String? = if (System.currentTimeMillis() - lastAt <= TTL_MS) lastContact else null
    fun clear() { lastContact = null }
}
