package com.jarvis.assistant.command

/** Explicit intents produced by [CommandParser]. */
sealed class Cmd {
    data class OpenApp(val name: String) : Cmd()
    data class WebSearch(val query: String) : Cmd()
    data class YouTubeSearch(val query: String) : Cmd()
    data class OpenSettings(val kind: String) : Cmd()
    data class WhatsApp(val recipient: String, val text: String) : Cmd()
    data class Swipe(val up: Boolean) : Cmd()
    /** direction: +1 louder, -1 quieter, 0 mute */
    data class Volume(val direction: Int) : Cmd()
    data class Torch(val on: Boolean) : Cmd()
    /** down = see lower content (scroll forward) */
    data class Scroll(val down: Boolean) : Cmd()
    data class TypeText(val text: String) : Cmd()
    data class WhatsAppOpenChat(val name: String) : Cmd()
    /** Message for the chat selected earlier ("usko ... message bhejo"); text null = still to be asked. */
    data class WhatsAppToContext(val text: String?) : Cmd()
    data class MissingArg(val question: String) : Cmd()
    data class Chat(val text: String) : Cmd()
    data class Unknown(val raw: String) : Cmd()
    object Greeting : Cmd()
    object TellTime : Cmd()
    object TellDate : Cmd()
    object AskName : Cmd()
    object AskUserName : Cmd()
    object Recents : Cmd()
    object Refresh : Cmd()
    object ClearText : Cmd()
    object Submit : Cmd()
    /** "jo main bolun use type karo": the next utterance is typed. */
    object Dictate : Cmd()
    object Lock : Cmd()
    object Back : Cmd()
    object Home : Cmd()
    object Stop : Cmd()
    object Yes : Cmd()
    object No : Cmd()
    object Thanks : Cmd()
    object HowAreYou : Cmd()
}
