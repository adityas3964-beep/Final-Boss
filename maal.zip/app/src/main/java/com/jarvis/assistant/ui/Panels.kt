package com.jarvis.assistant.ui

import android.app.admin.DevicePolicyManager
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.ai.AiClient
import com.jarvis.assistant.command.PermissionManager
import com.jarvis.assistant.data.AssistantState
import com.jarvis.assistant.voice.ModelDownloader
import com.jarvis.assistant.voice.VoskEngine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryPanel() {
    val app = LocalContext.current.applicationContext as JarvisApp
    val items by app.history.items.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        HudText("COMMAND HISTORY", size = 18.sp, color = Hud.Cyan, spacing = 3.sp, glow = true)
        HudButton("CLEAR HISTORY", { app.history.clear() }, Modifier.fillMaxWidth(), color = Hud.Bad, enabled = items.isNotEmpty())
        if (items.isEmpty()) HudText("Abhi koi command nahi.", color = Hud.Sub)
        items.forEach {
            HudPanel(SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(it.time)).uppercase() + "  [${it.source}]") {
                HudText("› ${it.heard}", size = 14.sp)
                HudText(it.reply, size = 13.sp, color = if (it.ok) Hud.Cyan else Hud.Warn)
            }
        }
    }
}

@Composable
fun ProfilePanel() {
    val app = LocalContext.current.applicationContext as JarvisApp
    val prefs by app.settings.prefs.collectAsStateWithLifecycle()
    var name by remember { mutableStateOf(prefs.userName) }
    var greet by remember { mutableStateOf(prefs.greeting) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        HudText("PROFILE", size = 18.sp, color = Hud.Cyan, spacing = 3.sp, glow = true)
        HudPanel("USER PROFILE") {
            HudField(name, { name = it; app.settings.update { p -> p.copy(userName = it.trim()) } }, "Aapka naam (FRIDAY isi naam se bulayega)")
            Spacer(Modifier.height(10.dp))
            HudField(greet, { greet = it; app.settings.update { p -> p.copy(greeting = it) } }, "Custom greeting (khaali = default)")
            Spacer(Modifier.height(6.dp))
            HudText("Awaaz, recognition mode aur wake word ki settings SETTINGS tab mein hain.", size = 11.sp, color = Hud.Sub)
        }
    }
}

@Composable
fun SystemPanel() {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as JarvisApp
    val prefs by app.settings.prefs.collectAsStateWithLifecycle()
    val progress by AssistantState.downloadProgress.collectAsStateWithLifecycle()
    val dlError by AssistantState.downloadError.collectAsStateWithLifecycle()
    val aiStatus by AssistantState.aiStatus.collectAsStateWithLifecycle()
    val tick = rememberResumeTick()
    val scope = rememberCoroutineScope()

    var endpoint by remember { mutableStateOf(prefs.aiEndpoint) }
    var model by remember { mutableStateOf(prefs.aiModel) }
    var key by remember { mutableStateOf("") }
    var keySaved by remember(tick) { mutableStateOf(app.settings.hasApiKey()) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun open(i: Intent) { try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        HudText("SETTINGS", size = 18.sp, color = Hud.Cyan, spacing = 3.sp, glow = true)

        RecognitionPanel()

        HudPanel("VOICE MODELS (VOSK, OFFLINE)") {
            HudText("Offline/Automatic recognition aur wake word ke liye zaroori. Online mode mein command ke liye nahi, sirf wake word ke liye chahiye.", size = 11.sp, color = Hud.Sub)
            Spacer(Modifier.height(6.dp))
            for ((lang, label) in listOf("en" to "ENGLISH (INDIA)", "hi" to "HINDI")) {
                val has = remember(tick, progress) { VoskEngine.hasModel(ctx, lang) }
                StatusRow(label, if (has) "INSTALLED" else "MISSING", has)
                HudButton(if (progress?.first == lang) "DOWNLOADING ${progress?.second}%" else "DOWNLOAD ${lang.uppercase()} MODEL (~40-50 MB)",
                    { app.scope.launch { ModelDownloader.download(ctx.applicationContext, lang) } },
                    Modifier.fillMaxWidth(), enabled = progress == null)
                Spacer(Modifier.height(8.dp))
            }
            dlError?.let { HudText(it, size = 12.sp, color = Hud.Bad) }
            HudText("Manual setup: model zip alphacephei.com/vosk/models se download karke extract karein aur folder ${VoskEngine.modelDir(ctx, "en").parentFile?.absolutePath}/en (ya /hi) mein rakhein, jisme 'am' folder ho.",
                size = 11.sp, color = Hud.Sub)
        }

        SpeechOutputPanel()

        WakeWordPanel()

        HudPanel("PERMISSIONS") {
            val mic = PermissionManager.mic(ctx); val con = PermissionManager.contacts(ctx)
            val ov = PermissionManager.overlay(ctx); val nt = PermissionManager.notifications(ctx)
            StatusRow("MICROPHONE", if (mic) "GRANTED" else "MISSING", mic)
            StatusRow("CONTACTS (WhatsApp naam)", if (con) "GRANTED" else "MISSING", con)
            StatusRow("NOTIFICATIONS", if (nt) "GRANTED" else "MISSING", nt)
            StatusRow("DISPLAY OVER OTHER APPS", if (ov) "GRANTED" else "MISSING", ov)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HudButton("CONTACTS", { permLauncher.launch(android.Manifest.permission.READ_CONTACTS) }, Modifier.weight(1f), enabled = !con)
                HudButton("OVERLAY", { open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))) }, Modifier.weight(1f), enabled = !ov)
            }
            Spacer(Modifier.height(8.dp))
            HudButton("APP PERMISSIONS (SYSTEM SETTINGS)", { open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))) }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            HudText("'Display over other apps' ke bina Android 10+ background se app/website nahi khulne deta.", size = 11.sp, color = Hud.Sub)
        }

        HudPanel("ACCESSIBILITY SERVICE") {
            val on = PermissionManager.accessibility(ctx)
            val up = PermissionManager.accessibilityConnected()
            StatusRow("STATUS", if (up) "CONNECTED" else if (on) "ENABLED (NOT CONNECTED)" else "OFF", up)
            HudText("Kyun chahiye: Back/Home/Recents/Lock, scroll, aapke bole hue text ko type karna, aur WhatsApp mein chat kholna aur (aapke confirm karne ke baad) message bhejna. Ye sirf aapka diya hua command chalate waqt foreground app ki screen padhta hai; screen ko chupchaap monitor nahi karta aur kuch store nahi karta. Aap ise kabhi bhi band kar sakte hain.",
                size = 12.sp, color = Hud.Sub)
            Spacer(Modifier.height(6.dp))
            HudText("Chalu kaise karein: neeche button dabayein > Installed/Downloaded apps mein FRIDAY > ON. Agar option grey ho (Android 13+ par APK sideload karne par): Phone Settings > Apps > FRIDAY > upar teen dots (⋮) > 'Allow restricted settings', phir dobara try karein.",
                size = 12.sp, color = Hud.Warn)
            Spacer(Modifier.height(8.dp))
            HudButton("OPEN ACCESSIBILITY SETTINGS", { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, Modifier.fillMaxWidth())
        }

        HudPanel("DEVICE ADMIN (PHONE LOCK)") {
            val on = PermissionManager.adminActive(ctx)
            StatusRow("STATUS", if (on) "ACTIVE" else "OFF", on)
            HudText("Sirf 'force-lock' policy: 'phone lock karo' bolne par screen lock hoti hai. Data wipe ya password change ki permission nahi maangi jaati.",
                size = 12.sp, color = Hud.Sub)
            Spacer(Modifier.height(8.dp))
            HudButton(if (on) "REMOVE DEVICE ADMIN" else "ACTIVATE DEVICE ADMIN", {
                val dpm = ctx.getSystemService(android.content.Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                if (on) dpm.removeActiveAdmin(PermissionManager.adminComponent(ctx))
                else open(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, PermissionManager.adminComponent(ctx))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "FRIDAY ko sirf screen lock karne ke liye."))
            }, Modifier.fillMaxWidth())
        }

        HudPanel("AI PROVIDER (OPTIONAL)") {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                HudText("ENABLE ONLINE AI", modifier = Modifier.weight(1f), size = 13.sp)
                Switch(prefs.aiEnabled, { app.settings.update { p -> p.copy(aiEnabled = it) } })
            }
            Spacer(Modifier.height(6.dp))
            HudField(endpoint, { endpoint = it; app.settings.update { p -> p.copy(aiEndpoint = it.trim()) } },
                "Endpoint (OpenAI-compatible /chat/completions URL)")
            Spacer(Modifier.height(8.dp))
            HudField(model, { model = it; app.settings.update { p -> p.copy(aiModel = it.trim()) } }, "Model name (optional)")
            Spacer(Modifier.height(8.dp))
            HudField(key, { key = it }, if (keySaved) "API key (saved, encrypted) — naya daalne par replace" else "API key (optional)", password = true)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HudButton("SAVE KEY", { app.settings.saveApiKey(key); key = ""; keySaved = app.settings.hasApiKey() }, Modifier.weight(1f))
                HudButton("TEST", {
                    AssistantState.aiStatus.value = "TESTING"
                    app.scope.launch {
                        val r = AiClient.chat(endpoint, app.settings.apiKey(), model, "", emptyList(), "Say OK")
                        AssistantState.aiStatus.value = if (r.isSuccess) "ONLINE" else "ERROR: ${r.exceptionOrNull()?.message}"
                    }
                }, Modifier.weight(1f), color = Hud.Blue, enabled = endpoint.isNotBlank())
            }
            Spacer(Modifier.height(6.dp))
            StatusRow("CONNECTION", if (prefs.aiEnabled) aiStatus else "OFF", if (prefs.aiEnabled && aiStatus == "ONLINE") true else null)
            HudText("AI ke liye internet (ya aapka local server) chahiye aur provider ki limits/charges lag sakte hain. Koi key app mein bundled nahi hai; key Android Keystore se encrypt hoti hai. Bina AI ke saare local commands chalte hain. AI jawab [AI] tag se alag dikhte hain.",
                size = 11.sp, color = Hud.Sub)
        }

        HudPanel("TROUBLESHOOTING") {
            HudText("• Mic start nahi hota: Permissions mein Microphone dein; Offline/wake word ke liye voice model download karein.\n" +
                "• App/website background se nahi khulta: 'Display over other apps' dein.\n" +
                "• Session band ho jata hai: battery optimization mein FRIDAY ko 'Unrestricted' karein; kuch phones (Xiaomi, Oppo, Vivo, Samsung) background mic rok dete hain.\n" +
                "• WhatsApp chat/Send kaam nahi karta: Accessibility 'CONNECTED' dikhni chahiye; WhatsApp ki language English/Hindi rakhein; update ke baad WhatsApp ke button/label badal sakte hain, tab FRIDAY sahi button na milne par fail batayega.\n" +
                "• Hindi awaaz nahi: Phone Settings > Text-to-speech mein Hindi voice data install karein.",
                size = 12.sp, color = Hud.Txt)
            Spacer(Modifier.height(8.dp))
            HudButton("BATTERY OPTIMIZATION SETTINGS", { open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }, Modifier.fillMaxWidth())
        }

        HudButton("RESET ALL SETTINGS", { app.settings.reset() }, Modifier.fillMaxWidth(), color = Hud.Bad)

        AboutCredits()
    }
}
