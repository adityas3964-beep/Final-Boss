package com.jarvis.assistant.command

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityNodeInfo
import com.jarvis.assistant.accessibility.JarvisAccessibilityService
import com.jarvis.assistant.accessibility.TypeOutcome
import kotlinx.coroutines.delay

/**
 * Drives the real WhatsApp UI through the Accessibility Service: search a contact, open the chat, type, press Send, and
 * check the screen afterwards. It uses only visible labels/hints (no private APIs). WhatsApp's layout changes between
 * versions and languages, so every step checks what is actually on screen and reports failure instead of guessing.
 */
class WhatsAppController(private val ctx: Context) {

    sealed class OpenResult {
        data class Opened(val name: String) : OpenResult()
        data class Ambiguous(val candidates: List<String>) : OpenResult()
        object NotFound : OpenResult()
        object NotInstalled : OpenResult()
        object NeedsAccessibility : OpenResult()
        data class Failed(val why: String) : OpenResult()
    }

    sealed class SendResult {
        object Sent : SendResult()
        /** Send was pressed and the text box emptied, but the new message bubble could not be seen. */
        object Unverified : SendResult()
        data class Failed(val why: String) : SendResult()
        /** The right chat could not be opened first; see the wrapped result. */
        data class NeedsOpen(val result: OpenResult) : SendResult()
    }

    private val packages = listOf("com.whatsapp", "com.whatsapp.w4b")

    fun isInstalled(): Boolean = packages.any { ctx.packageManager.getLaunchIntentForPackage(it) != null }

    private fun launch(): Boolean {
        for (p in packages) {
            val i = ctx.packageManager.getLaunchIntentForPackage(p) ?: continue
            try {
                ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return true
            } catch (_: Exception) { /* try the next package */ }
        }
        return false
    }

    private fun isWa(svc: JarvisAccessibilityService): Boolean = svc.currentPackage()?.startsWith("com.whatsapp") == true

    private suspend fun <T : Any> waitFor(timeoutMs: Long, stepMs: Long = 250, block: () -> T?): T? {
        val end = System.currentTimeMillis() + timeoutMs
        while (true) {
            val v = try { block() } catch (_: Exception) { null }
            if (v != null) return v
            if (System.currentTimeMillis() >= end) return null
            delay(stepMs)
        }
    }

    private suspend fun ensureWhatsApp(svc: JarvisAccessibilityService): Boolean {
        if (isWa(svc)) return true
        if (!launch()) return false
        return waitFor(6000) { if (isWa(svc)) true else null } == true
    }

    /** The home screen's search entry (a "Search" button or search bar), or null if we are not on the chat list. */
    private fun findSearchEntry(svc: JarvisAccessibilityService): AccessibilityNodeInfo? {
        val root = svc.rootInActiveWindow ?: return null
        if (root.packageName?.toString()?.startsWith("com.whatsapp") != true) return null
        if (findMessageEntry(svc) != null) return null   // inside a chat
        return svc.collect(root) { n ->
            val l = svc.label(n).lowercase()
            !n.isEditable && n.isVisibleToUser && (l == "search" || l.startsWith("search") || l.contains("or search") || l == "खोजें")
        }.firstOrNull()
    }

    /** The message input of an open chat. */
    private fun findMessageEntry(svc: JarvisAccessibilityService): AccessibilityNodeInfo? {
        val root = svc.rootInActiveWindow ?: return null
        if (root.packageName?.toString()?.startsWith("com.whatsapp") != true) return null
        val editors = svc.collect(root) { it.isEditable && it.isVisibleToUser }
        editors.firstOrNull { it.viewIdResourceName?.endsWith(":id/entry") == true }?.let { return it }
        return editors.firstOrNull {
            val h = ((it.hintText ?: it.text) ?: "").toString().lowercase()
            h.contains("message") || h.contains("मैसेज") || h.contains("संदेश")
        }
    }

    private fun chatOpenWith(svc: JarvisAccessibilityService, name: String): Boolean {
        if (!isWa(svc) || findMessageEntry(svc) == null) return false
        val root = svc.rootInActiveWindow ?: return false
        return svc.collect(root) { !it.isEditable && it.isVisibleToUser && svc.label(it).equals(name, ignoreCase = true) }.isNotEmpty()
    }

    private suspend fun goToChatList(svc: JarvisAccessibilityService): Boolean {
        repeat(5) {
            if (findSearchEntry(svc) != null) return true
            svc.global(AccessibilityService.GLOBAL_ACTION_BACK)
            delay(600)
            if (!isWa(svc)) { launch(); delay(1500) }
        }
        return findSearchEntry(svc) != null
    }

    /** Short visible texts that contain [query]: contact/chat names, not message previews. Distinct, in screen order. */
    private fun candidates(svc: JarvisAccessibilityService, query: String): List<String> {
        val q = query.trim().lowercase()
        val root = svc.rootInActiveWindow ?: return emptyList()
        val seen = LinkedHashMap<String, String>()
        for (n in svc.collect(root) { !it.isEditable && it.isVisibleToUser && it.text != null }) {
            val t = n.text?.toString()?.trim() ?: continue
            val l = t.lowercase()
            if (l.contains(q) && l.length <= q.length + 25 && !seen.containsKey(l)) seen[l] = t
        }
        return seen.values.toList()
    }

    /** Opens the chat for [name] by searching inside WhatsApp, and verifies the chat is actually showing. */
    suspend fun openChat(name: String): OpenResult {
        val svc = JarvisAccessibilityService.instance ?: return OpenResult.NeedsAccessibility
        if (!isInstalled()) return OpenResult.NotInstalled
        val query = name.trim()
        if (query.isEmpty()) return OpenResult.NotFound
        if (!ensureWhatsApp(svc)) return OpenResult.Failed("WhatsApp khul nahi paaya")
        if (!goToChatList(svc)) return OpenResult.Failed("WhatsApp ki chat list tak nahi pahunch paaya")
        val entry = findSearchEntry(svc) ?: return OpenResult.Failed("Search button nahi mila")
        if (!svc.clickNode(entry)) return OpenResult.Failed("Search khul nahi paaya")
        val field = waitFor(3000) { svc.findEditable(svc.rootInActiveWindow) } ?: return OpenResult.Failed("Search box nahi mila")
        if (svc.setTextOn(field, query, append = false) != TypeOutcome.OK) return OpenResult.Failed("Search box mein naam likh nahi paaya")

        waitFor(3500) { candidates(svc, query).takeIf { it.isNotEmpty() } } ?: return OpenResult.NotFound
        delay(900)   // let the rest of the results load before deciding whether the name is ambiguous
        val found = candidates(svc, query)
        val exact = found.filter { it.equals(query, ignoreCase = true) }
        val chosen = when {
            exact.size == 1 -> exact[0]
            found.size == 1 -> found[0]
            found.isEmpty() -> return OpenResult.NotFound
            else -> return OpenResult.Ambiguous(found)
        }

        val root = svc.rootInActiveWindow ?: return OpenResult.Failed("Screen read nahi ho payi")
        val row = svc.collect(root) { !it.isEditable && it.isVisibleToUser && it.text?.toString()?.trim().equals(chosen, ignoreCase = true) }
            .firstOrNull() ?: return OpenResult.Failed("Contact ki row nahi mili")
        if (!svc.clickNode(row)) return OpenResult.Failed("Chat tap nahi ho payi")

        val ok = waitFor(4500) { if (chatOpenWith(svc, chosen)) true else null }
        return if (ok == true) OpenResult.Opened(chosen) else OpenResult.Failed("Chat khuli hui screen par confirm nahi ho payi")
    }

    private fun countBubbles(svc: JarvisAccessibilityService, message: String): Int =
        svc.collect(svc.rootInActiveWindow) { !it.isEditable && it.text?.toString()?.trim() == message.trim() }.size

    private fun entryCleared(svc: JarvisAccessibilityService): Boolean {
        val e = findMessageEntry(svc) ?: return false
        e.refresh()
        return e.isShowingHintText || e.text.isNullOrEmpty()
    }

    /**
     * Types [message] into the chat with [contact] (reopening it if needed) and presses Send.
     * Only call this after the user has explicitly confirmed. Success is reported only after checking the screen.
     */
    suspend fun sendMessage(contact: String, message: String): SendResult {
        val svc = JarvisAccessibilityService.instance ?: return SendResult.NeedsOpen(OpenResult.NeedsAccessibility)
        if (!isInstalled()) return SendResult.NeedsOpen(OpenResult.NotInstalled)
        if (!chatOpenWith(svc, contact)) {
            val r = openChat(contact)
            if (r !is OpenResult.Opened) return SendResult.NeedsOpen(r)
        }
        val entry = waitFor(2500) { findMessageEntry(svc) } ?: return SendResult.Failed("message box nahi mila")
        when (svc.setTextOn(entry, message, append = false)) {
            TypeOutcome.OK -> {}
            TypeOutcome.PASSWORD -> return SendResult.Failed("ye field type nahi kar sakta")
            else -> return SendResult.Failed("message text box mein likh nahi paaya")
        }
        val before = countBubbles(svc, message)
        val send = waitFor(2500) { svc.findByLabel(svc.rootInActiveWindow, "send", "भेजें") }
            ?: return SendResult.Failed("Send button nahi mila. Message text box mein likha hai par bheja nahi gaya")
        if (!svc.clickNode(send)) return SendResult.Failed("Send button dab nahi paaya. Message bheja nahi gaya")

        val verified = waitFor(4000) { if (entryCleared(svc) && countBubbles(svc, message) > before) true else null }
        if (verified == true) return SendResult.Sent
        return if (entryCleared(svc)) SendResult.Unverified
        else SendResult.Failed("Send dabane ke baad bhi message text box mein hai; bheja nahi gaya")
    }
}
