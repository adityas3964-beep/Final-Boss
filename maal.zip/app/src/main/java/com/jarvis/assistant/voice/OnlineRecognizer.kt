package com.jarvis.assistant.voice

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Why an online recognition attempt ended without a usable result. */
enum class OnlineFailure {
    /** Network/service/language problem: an offline engine may take over. */
    SERVICE_UNAVAILABLE,
    /** Mic busy, permission, or audio problem: falling back would not help. */
    OTHER
}

/**
 * Online recognition through Android's SpeechRecognizer (normally Google's recogniser; it needs internet on most devices).
 * Must be used on the main thread. One session at a time; [cancel] is always safe.
 */
class OnlineRecognizer(private val context: Context) {
    interface Listener {
        fun onPartial(text: String)
        fun onFinal(text: String)
        /** Nothing was said / understood. */
        fun onNoSpeech()
        fun onFailure(kind: OnlineFailure, message: String)
    }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var watchdog: Runnable? = null
    private var active = false

    fun start(languageTag: String, listener: Listener) {
        cancel()
        val r = try { SpeechRecognizer.createSpeechRecognizer(context) } catch (e: Exception) {
            listener.onFailure(OnlineFailure.SERVICE_UNAVAILABLE, "Speech service nahi mili: ${e.message}")
            return
        }
        recognizer = r
        active = true
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                if (!active) return
                firstText(partialResults)?.let { listener.onPartial(it) }
            }
            override fun onResults(results: Bundle?) {
                if (!active) return
                finishSession()
                val t = firstText(results)
                if (t.isNullOrBlank()) listener.onNoSpeech() else listener.onFinal(t)
            }
            override fun onError(error: Int) {
                if (!active) return
                finishSession()
                when (error) {
                    ERROR_SPEECH_TIMEOUT, ERROR_NO_MATCH -> listener.onNoSpeech()
                    ERROR_NETWORK_TIMEOUT, ERROR_NETWORK, ERROR_SERVER, ERROR_CLIENT, ERROR_TOO_MANY_REQUESTS,
                    ERROR_SERVER_DISCONNECTED, ERROR_LANGUAGE_NOT_SUPPORTED, ERROR_LANGUAGE_UNAVAILABLE ->
                        listener.onFailure(OnlineFailure.SERVICE_UNAVAILABLE, describe(error))
                    else -> listener.onFailure(OnlineFailure.OTHER, describe(error))
                }
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        // Safety net: never wait forever if the recogniser stops calling back.
        val w = Runnable {
            if (active) { finishSession(); listener.onNoSpeech() }
        }
        watchdog = w
        main.postDelayed(w, 15000L)
        try { r.startListening(intent) } catch (e: Exception) {
            finishSession()
            listener.onFailure(OnlineFailure.SERVICE_UNAVAILABLE, "Online recognition shuru nahi hui: ${e.message}")
        }
    }

    /** Stops listening and releases the recogniser without delivering any callback. */
    fun cancel() {
        active = false
        watchdog?.let { main.removeCallbacks(it) }
        watchdog = null
        recognizer?.let {
            try { it.cancel() } catch (_: Exception) {}
            try { it.destroy() } catch (_: Exception) {}
        }
        recognizer = null
    }

    private fun finishSession() {
        active = false
        watchdog?.let { main.removeCallbacks(it) }
        watchdog = null
        recognizer?.let { try { it.destroy() } catch (_: Exception) {} }
        recognizer = null
    }

    private fun firstText(b: Bundle?): String? =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()

    private fun describe(error: Int) = when (error) {
        ERROR_NETWORK_TIMEOUT, ERROR_NETWORK -> "Internet connection nahi hai ya slow hai"
        ERROR_SERVER, ERROR_SERVER_DISCONNECTED, ERROR_TOO_MANY_REQUESTS -> "Speech service abhi available nahi hai"
        ERROR_LANGUAGE_NOT_SUPPORTED, ERROR_LANGUAGE_UNAVAILABLE -> "Ye bhasha is phone ki speech service par available nahi hai"
        ERROR_CLIENT -> "Speech service se connect nahi ho paaya"
        ERROR_AUDIO -> "Microphone audio error"
        ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission nahi hai"
        ERROR_RECOGNIZER_BUSY -> "Speech service busy hai"
        else -> "Speech recognition error ($error)"
    }

    companion object {
        // Values of SpeechRecognizer.ERROR_*; literals so the newer (API 31) codes need no version checks.
        private const val ERROR_NETWORK_TIMEOUT = 1
        private const val ERROR_NETWORK = 2
        private const val ERROR_AUDIO = 3
        private const val ERROR_SERVER = 4
        private const val ERROR_CLIENT = 5
        private const val ERROR_SPEECH_TIMEOUT = 6
        private const val ERROR_NO_MATCH = 7
        private const val ERROR_RECOGNIZER_BUSY = 8
        private const val ERROR_INSUFFICIENT_PERMISSIONS = 9
        private const val ERROR_TOO_MANY_REQUESTS = 10
        private const val ERROR_SERVER_DISCONNECTED = 11
        private const val ERROR_LANGUAGE_NOT_SUPPORTED = 12
        private const val ERROR_LANGUAGE_UNAVAILABLE = 13

        fun isAvailable(context: Context): Boolean =
            try { SpeechRecognizer.isRecognitionAvailable(context) } catch (_: Exception) { false }

        /** True if the device reports a validated internet connection. */
        fun hasInternet(context: Context): Boolean = try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (_: Exception) { false }
    }
}
