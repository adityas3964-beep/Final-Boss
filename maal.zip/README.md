# F.R.I.D.A.Y — native Android voice assistant (Kotlin + Jetpack Compose)

Package/application ID `com.jarvis.assistant` is unchanged on purpose (installs over the old build, settings and your saved Groq endpoint/key/model carry over).

> **Honest status:** this source has **not been compiled, unit-tested or run on a phone**. The authoring sandbox had no Gradle, Android SDK or network. The first GitHub Actions run is the first real compile. If it fails, send the red `error:` lines. See PROGRESS.md for exactly what was and was not verified.

## Build
- **GitHub:** push the project (or only `friday-android-project.zip`, the workflow unzips it) → **Actions → Build FRIDAY debug APK → Run workflow** → Artifacts → `friday-debug-apk`.
- **Local:** `gradle :app:assembleDebug` (Gradle 8.7, JDK 17, Android SDK 34); tests: `gradle :app:testDebugUnitTest`. Output: `app/build/outputs/apk/debug/app-debug.apk`.
- Versions: single module `:app` · minSdk 26 · compileSdk/targetSdk 34 · AGP 8.5.2 · Kotlin 1.9.24 · Compose compiler 1.5.14 · no flavors · no Gradle wrapper included.

## How a command flows
1. Speech recognition (Online / Offline / Automatic; wake word local).
2. `CommandParser` (+ `Normalizer`) handles known Hindi/Hinglish/English commands locally, also offline.
3. Anything unrecognised goes to your existing AI provider (same endpoint, key, model). The model replies with one JSON action; `ActionPlanner` validates it against an **allowlist** and the local `CommandDispatcher` executes it. Arbitrary code is never executed, the model can never confirm anything, and WhatsApp sends always need your spoken "haan". Plain-text AI replies still work as normal chat.
4. Every result carries a status: `ACTION_STARTED, ACTION_SUCCESS, ACTION_FAILED, NEEDS_CONFIRMATION, NEEDS_PERMISSION, TARGET_NOT_FOUND, AMBIGUOUS_CONTACT, UNSUPPORTED_ACTION` (shown on the Home screen as LAST ACTION RESULT).

## Commands
Apps (YouTube, WhatsApp, Chrome, Settings, Gallery, Camera, Phone/dialer, Calculator) · Back, Home, Recents · scroll up/down · refresh (pull-down gesture, result not verifiable) · "Search box mein Hello likho", "jo main bolun use type karo" (dictation), "search karo" (presses search), "text clear karo" · volume up/down/mute · torch · Wi-Fi/Bluetooth/Brightness settings · WhatsApp: "Kartavya ki chat kholo" → "Usko Hi message bhejo" → "Boss, Kartavya ko 'Hi' message bhejna hai. Confirm karun?" → "haan".

## Accessibility service (required for typing, scrolling, WhatsApp chats, Back/Home/Recents)
Enable manually: Settings > Accessibility > Installed/Downloaded apps > FRIDAY > ON. On Android 13+ with a sideloaded APK the switch may be greyed out: Settings > Apps > FRIDAY > ⋮ > **Allow restricted settings**, then enable it. The service now covers all apps (it no longer has a WhatsApp-only filter) because typing/scrolling must work anywhere; it only reads the screen while executing a command you gave and stores nothing.

## WhatsApp automation
Uses WhatsApp's real UI via Accessibility (search → pick the chat → type → press Send) and checks the screen after each step. Ambiguous names ("Kartavya Sharma" / "Kartavya Singh") trigger a question. Success is reported only if the text box emptied and a new message bubble appeared; otherwise you get "unverified" or "failed". WhatsApp's layout changes between versions/languages, so this needs real-device testing; without Accessibility the old Contacts + `wa.me` path opens the chat with the text prefilled and you press Send yourself.

## Limits
No phone calls, payments, passwords or other sensitive actions are performed (password fields are refused). Contact names are matched as typed in WhatsApp; Devanagari speech for a Latin-spelled contact will not match. Offline mode cannot use cloud AI. Torch/volume use standard Android APIs but are untested on devices.
